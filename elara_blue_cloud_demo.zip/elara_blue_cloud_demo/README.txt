ELARA BLUE & CLOUD DEMO WEBSITE

What this is:
- A standalone, responsive HTML/CSS demo with a blue-and-white cloud theme.
- It does not connect to or change your existing Elara website.
- It does not collect or store enquiries.

How to preview:
1. Extract this ZIP to a folder on your computer.
2. Double-click index.html.
3. It should open in your browser.

Before publishing:
- Replace sample phone/email details and check every service description.
- Replace the placeholder contact button with your real enquiry/WhatsApp link.
- Confirm the official centre name, address, service scope, and workshop details.
- Do not publish any child/client photos or private information without appropriate permission.

You can edit index.html in a plain text editor such as Notepad. Save a backup before making changes.
